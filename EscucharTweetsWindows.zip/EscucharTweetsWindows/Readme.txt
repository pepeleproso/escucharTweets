1- Instalar python-3.5.3-amd64-webinstall.exe siguiendo el asistente. Elegir que se agregue python.exe al PATH.
2- Instalar pywin32-221.win-amd64-py3.5.exe siguiendo el asistente
3- Ejecutar EscucharTweets.bat

